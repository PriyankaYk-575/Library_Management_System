
import tkinter as tk
from tkinter import messagebox
from tkinter import PhotoImage
from tkinter import font
from datetime import date
from tkinter import ttk
from datetime import datetime, timedelta
from tkcalendar import DateEntry 
import customtkinter as ctk


import mysql.connector

# Connect to MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456789",
    database="library_db"
)

# Create a cursor
cursor = db.cursor()

# Function to create the admin table if not exists
def create_admin_table():
    query = """
    CREATE TABLE IF NOT EXISTS admin (
        username VARCHAR(255) PRIMARY KEY,
        password VARCHAR(255) NOT NULL
    )"""
    cursor.execute(query)
    db.commit()


def on_hover1(event):
    event.widget.configure(bg='pink')
def on_default1(event):
    event.widget.configure(bg='sky blue')
def on_defaultE1(event):
    event.widget.configure(bg='gray')

# Function to open the admin login window
def open_admin_login_window():
    login_window = tk.Toplevel(app)
    login_window.title("Admin Login")
    login_window.geometry("{0}x{1}+0+0".format(login_window.winfo_screenwidth(), login_window.winfo_screenheight()))
    
    # Hide the current window
    #app.withdraw()

    BACKGROUND_IMAGE_PATH22='admbg1.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH22)

    # Create a Label to display the background image
    background_label = tk.Label(login_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image


    login_window.configure(bg='gray1')
    cent_f=ctk.CTkFrame(master=login_window,fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"),width=400,height=350)
    #cent_f.grid(row=400,column=400)
    cent_f.pack(pady=(130,0))
    
    ctk.CTkLabel(master=cent_f,text="ADMIN LOGIN",width=120,fg_color="#cbee76",text_color="black",font=('Imprint MT Shadow', 35)).place(x=70,y=40)
    label_config = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 5, 'width': 10}
    tk.Label(cent_f, text="Username:",**label_config).place(x=60,y=120)
    tk.Label(cent_f, text="Password:",**label_config).place(x=60,y=160)
    # Set a vertical gap (row spacing) between labels
    row_gap = 30
    for i in range(10):
        login_window.grid_rowconfigure(i, minsize=row_gap)

    entry_config = {'font': ('times new roman', 13), 'width': 20}
    entry_username = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter username",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_password = ctk.CTkEntry(cent_f,border_width=1, placeholder_text="Enter password",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black",show="*")

    entry_username.place(x=170,y=120)
    entry_password.place(x=170,y=160)

    
    def my_show():
        if entry_password.cget('show')=='*':
            entry_password.configure(show='')
        else:
            entry_password.configure(show='*')
    
    cb=ctk.CTkCheckBox(cent_f,text='Show password',command=my_show,text_color="black",font=("times new roman", 13))
    cb.place(x=205,y=200)

    def login():
        entered_username = entry_username.get()
        entered_password = entry_password.get()

        # Check if username and password are not empty
        if not entered_username or not entered_password:
            messagebox.showwarning("Warning", "Please enter both username and password",parent=login_window)
            return 
        # Check if the entered credentials exist in the database
        if check_existing_admin_credentials(entered_username, entered_password):
            login_window.destroy()
            open_admin_options_window()
            
        else:
            messagebox.showerror("Error", "Incorrect username or password",parent=login_window)

    btn=ctk.CTkButton(cent_f,command=login,text="Login",width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=80,y=260)

    btn=ctk.CTkButton(cent_f, text="Edit",width=70,cursor='hand2',hover_color="pink",command=edit_admin_credentials,font=("times new roman", 18),fg_color="sky blue",text_color="black")
    
    btn.place(x=165,y=260)

    btn=ctk.CTkButton(cent_f, text="Exit",cursor='hand2',width=60 ,hover_color="pink",command=login_window.destroy,font=("times new roman", 18),fg_color="gray",text_color="black")
    
    btn.place(x=250,y=260)

# Function to check if the admin credentials exist
def check_existing_admin_credentials(username, password):
    query = "SELECT * FROM admin"
    cursor.execute(query)
    existing_credentials = cursor.fetchall()

    if len(existing_credentials) > 0:
        return existing_credentials[0][0] == username and existing_credentials[0][1] == password
    else:
        return False

# Function to insert admin credentials (used for initial setup)
def insert_initial_admin(username, password):
    query = "INSERT INTO admin (username, password) VALUES (%s, %s)"
    values = (username, password)
    cursor.execute(query, values)
    db.commit()

# Assuming 'background_image.png' is the image file in the same directory as your script

  # Change every 2 seconds
    
# Function to open the stud options window
def open_stud_options_window():
    stud_options_window = tk.Toplevel(app)
    stud_options_window.title("Library Management System - Student Options")
    stud_options_window.geometry("{0}x{1}+0+0".format(stud_options_window.winfo_screenwidth(), stud_options_window.winfo_screenheight()))

    
    # cent_f=tk.Frame(master=stud_options_window,bg='#a5eb7f',highlightbackground='gray7',highlightthickness=1)
    # #cent_f.grid(row=400,column=400)
    # cent_f.pack(side='top',fill="both",expand=False)

    lef_f=tk.Frame(master=stud_options_window,bg='#9162e2',highlightbackground='gray15',highlightthickness=1,width=230)
    #cent_f.grid(row=400,column=400)
    #lef_f.pack(pady=(50,0))
    lef_f.pack(side='left',fill="both",expand=False)

    BACKGROUND_IMAGE_PATH22='x11.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH22)

    # Create a Label to display the background image
    background_label = tk.Label(lef_f, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image

    rei_f=tk.Frame(master=stud_options_window,bg='#a5eb7f',highlightbackground='gray15',highlightthickness=2,width=1500,height=650)
    rei_f.pack(pady=(0,0))

    BACKGROUND_IMAGE_PATH2='lib_bg2.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH2)

    # Create a Label to display the background image
    background_label = tk.Label(rei_f,bg="#a5eb7f", image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    # Create a bold font
    bold_font = font.Font(weight="bold")

    def on_hover2(event):
        event.widget.configure(bg='pink')
    def on_default2(event):
        event.widget.configure(bg='#a5eb7f')
    def on_defaultE2(event):
        event.widget.configure(bg='gray')
    
    # Title and Welcome Message
    #tk.Label(cent_f, text="LIBRARY MANAGEMENT SYSTEM",bg="#dcf8b4", font=("Algerian", 45)).pack(pady=25)
    #tk.Label(stud_options_window, text="...Welcome...",bg="bisque3", font=("Algerian", 17)).pack(pady=30)

    # Set a fixed width for the buttons
    button_width = 13
    
    # Buttons
    btn=ctk.CTkButton(lef_f, text="Search" ,command=search_books,border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    
    btn.place(x=45,y=320)
    btn=ctk.CTkButton(lef_f, text="Exit",command=stud_options_window.destroy,width=90,cursor='hand2',hover_color="pink",fg_color="gray",font=("times new roman", 20),background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),corner_radius=7,text_color="black")
    
    btn.place(x=70,y=365)
    

# Function to open the admin options window
def open_admin_options_window():
    admin_options_window = tk.Toplevel(app)
    admin_options_window.title("Library Management System - Admin Options")
    admin_options_window.geometry("{0}x{1}+0+0".format(admin_options_window.winfo_screenwidth(), admin_options_window.winfo_screenheight()))

    # cent_f=tk.Frame(master=admin_options_window,bg='#9162e2',highlightbackground='gray9',highlightthickness=1)
    # #cent_f.grid(row=400,column=400)
    # cent_f.pack(side='top',fill="both",expand=False)

    lef_f=tk.Frame(master=admin_options_window,bg='#9162e2',highlightbackground='gray15',highlightthickness=1,width=250)
    #cent_f.grid(row=400,column=400)
    #lef_f.pack(pady=(50,0))
    lef_f.pack(side='left',fill="both",expand=False)

    BACKGROUND_IMAGE_PATH22='x11.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH22)

    # Create a Label to display the background image
    background_label = tk.Label(lef_f, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image

    rei_f=tk.Frame(master=admin_options_window,bg='purple',highlightbackground='gray15',highlightthickness=2,width=1100,height=650)
    rei_f.pack()

    BACKGROUND_IMAGE_PATH2='lib_bg2.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH2)

    # Create a Label to display the background image
    background_label = tk.Label(rei_f,bg="#a5eb7f", image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    
    
    # Create a bold font
    bold_font = font.Font(weight="bold")
    
    # Title and Welcome Message
    # l1=tk.Label(cent_f, text="LIBRARY MANAGEMENT SYSTEM",bg="#9162e2", font=("Algerian", 45))
    # l1.pack(pady=30)
    
    # Set a fixed width for the buttons
    button_width = 13

    def on_hover2(event):
        event.widget.configure(bg='pink')
    def on_default2(event):
        event.widget.configure(bg='#a5eb7f')
    def on_defaultE2(event):
        event.widget.configure(bg='gray')
    
    # Buttons
    btn=ctk.CTkButton(lef_f, text="Add Book",command=add_books,border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    btn.place(x=55,y=240)
    
    btn=ctk.CTkButton(lef_f, text="Search",command=search_books, border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    btn.place(x=55,y=290)
    # btn=tk.Button(lef_f, text="Remove Book",cursor='hand2', command=remove_book, width=12, bg="#b18ee3",font=("Britannic Bold", 17),activebackground='lawn green',relief='groove')
    # btn.bind('<Enter>',on_hover2)
    # btn.bind('<Leave>',on_default2)
    # btn.place(x=50,y=160)
    btn=ctk.CTkButton(lef_f, text="Edit",command=edit_book,border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    btn.place(x=55,y=340)
    
    btn=ctk.CTkButton(lef_f, text="Issue",command=issue_books,border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    btn.place(x=55,y=390)
   
    btn=ctk.CTkButton(lef_f, text="Return", command=return_books, border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    btn.place(x=55,y=440)
    
    btn=ctk.CTkButton(lef_f, text="Issue list", command=open_issued_books_window, border_color="#15a613",cursor='hand2',hover_color="pink",fg_color="#a5eb7f",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 23),border_width=1,corner_radius=7,text_color="black")
    btn.place(x=55,y=490)
    
    btn=ctk.CTkButton(lef_f, text="Logout",width=90, command=admin_options_window.destroy,border_color="gray",cursor='hand2',hover_color="pink",fg_color="gray",background_corner_colors=("#eaf8cb","#eaf8cb","#eaf8cb","#eaf8cb"),font=("times new roman", 18),border_width=1,corner_radius=7,text_color="black")
    
    btn.place(x=80,y=540)
    




def add_books():
    add_books_window = tk.Toplevel()
    add_books_window.title("Add Books")
    add_books_window.geometry("{0}x{1}+0+0".format(add_books_window.winfo_screenwidth(), add_books_window.winfo_screenheight()))

    add_books_window.configure(bg='#9162e2')

    BACKGROUND_IMAGE_PATH12 = 'bgcen.png'
    # Load the background image
    background_image = tk.PhotoImage(file=BACKGROUND_IMAGE_PATH12)

    # Create a Label to display the background image
    background_label = tk.Label(add_books_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image

    # lef_f = tk.Frame(master=add_books_window, bg='#a7f1b2', highlightbackground='gray15', highlightthickness=1, width=200)
    # lef_f.pack(side='left', fill="both", expand=False)

    

    cent_f =ctk.CTkFrame(master=add_books_window, fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"),
                      width=420, height=400)
    cent_f.pack(pady=(100,0))

    label_config = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 5}

    # Labels and Entry Fields for Book Information
    tk.Label(cent_f, text="Book ID:", **label_config).place(x=60, y=30)
    tk.Label(cent_f, text="Book Name:", **label_config).place(x=36, y=60)
    tk.Label(cent_f, text="Author:", **label_config).place(x=68, y=90)
    tk.Label(cent_f, text="Publish Year:", **label_config).place(x=24, y=120)
    tk.Label(cent_f, text="Genre:", **label_config).place(x=71, y=150)

    tk.Label(cent_f, text="Language:", **label_config).place(x=47, y=180)
    tk.Label(cent_f, text="Publisher:", **label_config).place(x=45, y=210)
    tk.Label(cent_f, text="Added Date:", **label_config).place(x=37, y=240)
    tk.Label(cent_f, text="Total Copies:", **label_config).place(x=26, y=270)
    tk.Label(cent_f, text="Shelf Location:", **label_config).place(x=16, y=300)

    # Set a vertical gap (row spacing) between labels
    row_gap = 30
    for i in range(10):
        add_books_window.grid_rowconfigure(i, minsize=row_gap)

    entry_config = {'font': ('times new roman', 13), 'width': 24}
    entry_book_id = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter BookID",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_book_name = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter book name",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_author = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter author",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_publish_year = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter publish year",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_genre = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter genre",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_language = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter language",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_publisher = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter publisher",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_total_copies = ctk.CTkEntry(cent_f, border_width=1,validate='key',placeholder_text="Enter total copies",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_shelf_location = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter shelf location",border_color="#15a613",width=220,font=('times new roman', 17),fg_color=("white"),text_color="black")

    entry_book_id.place(x=150, y=30)
    entry_book_name.place(x=150, y=60)
    entry_author.place(x=150, y=90)
    entry_publish_year.place(x=150, y=120)
    entry_genre.place(x=150, y=150)
    entry_language.place(x=150, y=180)
    entry_publisher.place(x=150, y=210)

    # Replace the entry_added_date with DateEntry widget
    entry_added_date = DateEntry(cent_f,border_color="#15a613",width=22,border_width=2,font=('times new roman', 13),fg_color=("white"),text_color="black" ,date_pattern="YYYY-MM-DD")
    entry_added_date.place(x=150, y=240)

    entry_total_copies.place(x=150, y=270)
    entry_shelf_location.place(x=150, y=300)

    #Validate entry_total_copies as it should only accept integers
    #validate_int = add_books_window.register(lambda s: s.isdigit() or s == "")
    #entry_total_copies.configure(validate="key", validatecommand=(validate_int, "%P"))

    # Button to add the book
    def add_book():
        book_id = entry_book_id.get()
        book_name = entry_book_name.get()
        author = entry_author.get()
        publish_year = entry_publish_year.get()
        genre = entry_genre.get()
        language = entry_language.get()
        publisher = entry_publisher.get()
        added_date = entry_added_date.get()
        total_copies = entry_total_copies.get()
        shelf_location = entry_shelf_location.get()

        if not book_id or not book_name or not author or not publish_year or not genre or not language or not added_date or not total_copies or not shelf_location:
            messagebox.showwarning("Warning", "Please fill every field", parent=add_books_window)
            return

        
                
        
        # Ensure the book ID is unique
        if check_book_id_uniqueness(book_id):
            # Insert the book into the database
            insert_book(book_id, book_name, author, publish_year, genre, language, publisher,
                        added_date, total_copies, shelf_location)
            messagebox.showinfo("Success", "Book added successfully!", parent=add_books_window)

            
            
            
            
            

        else:
            messagebox.showerror("Error", "Book ID must be unique", parent=add_books_window)

    def clear_fun():
        entry_book_id.delete(0, 'end')
        entry_book_name.delete(0, 'end')
        entry_author.delete(0, 'end')
        entry_publish_year.delete(0, 'end')
        entry_genre.delete(0, 'end')
        entry_language.delete(0, 'end')
        entry_publisher.delete(0, 'end')
        entry_total_copies.delete(0,'end')
        entry_shelf_location.delete(0, 'end')   

    # Function to go back to admin options window
    def go_back():
        add_books_window.destroy()

    btn = ctk.CTkButton(cent_f, text="Add Book", command=add_book, width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=70, y=350)
    btn = ctk.CTkButton(cent_f, text="Back",command=go_back, width=70,cursor='hand2',hover_color="pink",fg_color="gray",font=("times new roman", 18),text_color="black")
   
    btn.place(x=280, y=350)

    btn = ctk.CTkButton(cent_f, text="Clear",command=clear_fun, width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    btn.place(x=180, y=350)

# Function to check if the book ID is unique
def check_book_id_uniqueness(book_id):
    query = "SELECT * FROM books WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    return cursor.fetchone() is None

# Function to insert book into the database
def insert_book(book_id, book_name, author, publish_year, genre, language, publisher,
                added_date, total_copies, shelf_location):
    query = """
    INSERT INTO books (book_id, book_name, author, publish_year, genre, language, publisher,
                      added_date, total_copies, shelf_location)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"""
    values = (book_id, book_name, author, publish_year, genre, language, publisher,
              added_date, total_copies, shelf_location)
    cursor.execute(query, values)
    db.commit()




# Function to search books with pagination
def search_books():
    search_book_window = tk.Toplevel()
    search_book_window.title("Search Book")
    search_book_window.geometry("{0}x{1}+0+0".format(search_book_window.winfo_screenwidth(), search_book_window.winfo_screenheight()))
    search_book_window.configure(bg='#9162e2')

    BACKGROUND_IMAGE_PATH12 = 'bgcen.png'
    # Load the background image
    background_image = tk.PhotoImage(file=BACKGROUND_IMAGE_PATH12)

    # Create a Label to display the background image
    background_label = tk.Label(search_book_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image

    

    # Create a frame for the left side
    # lef_f = tk.Frame(master=search_book_window, bg='#a7f1b2', highlightbackground='gray15', highlightthickness=1, width=200)
    # lef_f.pack(side='left', fill="both", expand=False)

    
    cent_f = ctk.CTkFrame(master=search_book_window, fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"), width=1100,
                      height=480)
    cent_f.pack(pady=(85, 0))

    label_config2 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 5, 'width': 29}
    tk.Label(cent_f, text="Enter Book ID or Book Name:", **label_config2).place(x=25, y=50)

    entry_config = {'font': ('times new roman', 13), 'width': 17}
    entry_search_input = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter Book ID or name",border_color="#15a613",width=180,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_search_input.place(x=300, y=50)
    label_config3 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 5, 'width': 20}
    tk.Label(cent_f, text="Explore genre:", **label_config3).place(x=500, y=50)

    entry_config2 = {'font': ('times new roman', 13), 'width': 10}
    # Combobox for selecting genre
    genre_combobox = ttk.Combobox(cent_f, values=["All","Poem", "Fantasy", "Mystry", "Education","Novel","Story","Others"],
                                  state="readonly", **entry_config2)
    genre_combobox.set("All")
    genre_combobox.place(x=670, y=50)


    def search_for_book():
        search_input = entry_search_input.get()
        selected_genre = genre_combobox.get()
        if not search_input and selected_genre == "All":
            # Clear previous result
            
            search_book_window.result_tree.destroy()
            messagebox.showerror("Failed", "Please enter a Book ID or Book Name or select a Genre",parent=search_book_window)
            return

        if search_input.isdigit():
            # Search by book ID
            book_details_list = search_by_book_id(search_input)
        elif not search_input and selected_genre != "All":
            # Search only by genre
            book_details_list = search_by_genre(selected_genre)
        else:
            # Search by book name and genre
            book_details_list = search_by_book_name(search_input, selected_genre)

        # Clear previous result
        if hasattr(search_book_window, 'result_tree'):
            search_book_window.result_tree.destroy()
        if book_details_list:
            if isinstance(book_details_list[0], int):
                messagebox.showinfo("Failed", "Error: Incomplete book details")
            else:
                # Set the background color of the result_tree
                style = ttk.Style()
                style.configure("Treeview", background="#d9e4d1",font=('times new roman',12))
                style.configure("Treeview.Heading", font=('times new roman',12,'bold'))
                # Create and display the result_tree
                result_tree = ttk.Treeview(cent_f, columns=(
                    "Book ID", "Book Name", "Author", "Publish Year", "Genre",
                    "Language", "Publisher", "Added Date", "Total Copies", "Shelf Location"
                ), show="headings", selectmode="browse")

                

                # Set column widths
                column_widths = [70, 150, 110, 110, 90, 90, 115, 120, 95, 120]
                for i, col in enumerate(result_tree["columns"]):
                    result_tree.heading(col, text=col)
                    result_tree.column(col, width=column_widths[i])

                result_tree.place(x=10, y=160)

                for book_details in book_details_list:
                    result_tree.insert("", "end", values=book_details)

                # Create a vertical scrollbar
                vsb = ttk.Scrollbar(cent_f, orient="vertical", command=result_tree.yview)

                # Attach the scrollbar to the treeview
                result_tree.configure(yscrollcommand=vsb.set)

                # Set the scrollbar and treeview geometry
                vsb.place(x=11 + sum(column_widths), y=160, height=250)  # Adjust the height as needed
                result_tree.place(x=10, y=160, height=250)

                # Save the result_tree reference in the window for future destruction
                search_book_window.result_tree = result_tree
                
                # Save the result_tree reference in the window for future destruction
                search_book_window.result_tree = result_tree

        else:
            messagebox.showinfo("Failed", "Sorry! Book not found in the database.",parent=search_book_window)
          

    # Button to search for the book
    btn=ctk.CTkButton(cent_f, text="Search", command=search_for_book,width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=820, y=45)

    # Button to go back to admin options window
    btn=ctk.CTkButton(cent_f, text="Back",cursor='hand2', command=search_book_window.destroy,width=70,hover_color="pink",fg_color="gray",font=("times new roman", 17),text_color="black")
    
    btn.place(x=900, y=45)


# Modify the search_by_book_id function
def search_by_book_id(book_id):
    query = "SELECT * FROM books WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    return cursor.fetchall()

# Modify the search_by_book_name function
# Modify the search_by_book_name function
def search_by_book_name(book_name, genre=None):
    if len(book_name) < 4:
        return None

    query = """
        SELECT b.*
        FROM books b
        JOIN (
            SELECT MIN(book_id) AS min_book_id
            FROM books
            WHERE LOWER(book_name) LIKE LOWER(%s)
            """
    
    parameters = ('%' + book_name + '%',)

    if genre and genre != "All":
        query += " AND genre = %s"
        parameters += (genre,)

    query += """
            GROUP BY book_name, author, publish_year, genre, language, publisher, added_date, total_copies, shelf_location
        ) AS subquery ON b.book_id = subquery.min_book_id
    """
    
    cursor.execute(query, parameters)
    return cursor.fetchall()


# Modify the search_by_genre function
def search_by_genre(genre):
    if genre == "All":
        query = "SELECT DISTINCT * FROM books"
    else:
        query = """
            SELECT b.*
            FROM books b
            JOIN (
                SELECT MIN(book_id) AS min_book_id
                FROM books
                WHERE genre = %s
                GROUP BY book_name, author, publish_year, genre, language, publisher, added_date, total_copies, shelf_location
            ) AS subquery ON b.book_id = subquery.min_book_id
        """
        cursor.execute(query, (genre,))
    
    return cursor.fetchall()

    
# Function to open the window for removing books
def remove_book():
    remove_book_window = tk.Toplevel()
    remove_book_window.title("Remove Book")
    remove_book_window.geometry("{0}x{1}+0+0".format(remove_book_window.winfo_screenwidth(), remove_book_window.winfo_screenheight()))

    remove_book_window.configure(bg='#9162e2')
    lef_f=tk.Frame(master=remove_book_window,bg='slate blue2',highlightbackground='gray15',highlightthickness=1,width=250)
    lef_f.pack(side='left',fill="both",expand=False)

    BACKGROUND_IMAGE_PATH2='sideP2.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH2)

    # Create a Label to display the background image
    background_label = tk.Label(lef_f, image=background_image)
    background_label.place(relwidth=1, relheight=1)



    # Set the background image to be transparent
    background_label.image = background_image

    cent_f=tk.Frame(master= remove_book_window,bg='#a078e6',highlightbackground='slate blue3',highlightthickness=3,width=500,height=500)
    #cent_f.grid(row=400,column=400)
    cent_f.pack(pady=(60,0))


    
    tk.Label(cent_f, text="Enter Book ID to Remove:",font=("times new roman", 13,'bold'),bg='#a078e6').place(x=75,y=60)
    entry_book_id = tk.Entry(cent_f,font=("times new roman", 13),width=15)
    entry_book_id.place(x=280,y=60)

    
    # Function to remove the book
    def remove_book_by_id():
        book_id = entry_book_id.get()

        # Display details of the deleted book
        result_text = tk.Text(cent_f, wrap=tk.WORD, width=38, height=15,font=("times new roman", 13),bg='#a078e6')
        result_text.place(x=80,y=150)
        # Check if the book is issued
        if check_if_book_issued(book_id):
            result_text.insert(tk.END, "Error: Cannot remove book. Book is currently issued to a student.")
        else:
            if not check_book_id_uniqueness(book_id):
                # Get details of the book before removing
                book_details = get_book_details(book_id)

                #Remove the book from the database
                delete_book(book_id)

                # Display details of the deleted book
                details_text = (
                f"Book ID             :{book_details[0]}"
                f"\nBook Name       :{book_details[1]}"
                f"\nAuthor                :{book_details[2]}"
                f"\nPublish Year      :{book_details[3]}"
                f"\nGenre                 :{book_details[4]}"
                f"\nLanguage           :{book_details[5]}"
                f"\nPublisher           :{book_details[6]}"
                f"\nAdded Date       :{book_details[7]}"
                f"\nTotal Copies     :{book_details[8]}"
                f"\nShelf Location  :{book_details[9]}\n"
                f"\nBook removed successfully!"
                )
                result_text.insert(tk.END, details_text)
            else:
                result_text.insert(tk.END, "Error: Book ID not found")

    btn=tk.Button(cent_f, text="Remove Book",cursor='hand2', command=remove_book_by_id,activebackground='lawn green',bg="sky blue",font=("times new roman", 12))
    btn.bind('<Enter>',on_hover1)
    btn.bind('<Leave>',on_default1)
    btn.place(x=150,y=100)
    # Add a "Back" button to navigate to admin options window
    btn = tk.Button(cent_f, text="Back",cursor='hand2',activebackground='lawn green', command=remove_book_window.destroy,bg="gray",font=("times new roman", 11))
    btn.bind('<Enter>',on_hover1)
    btn.bind('<Leave>',on_defaultE1)
    btn.place(x=280,y=100)

def check_if_book_issued(book_id):
    query = "SELECT * FROM issued WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    return bool(cursor.fetchone())  # Returns True if there is at least one record (book is issued), False otherwise

# Function to delete book from the database
def delete_book(book_id):
    query = "DELETE FROM books WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    db.commit()

# Function to get details of the book by book_id
def get_book_details(book_id):
    query = "SELECT * FROM books WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    return cursor.fetchone()

# Function to check if the book ID is unique
def check_book_id_uniqueness(book_id):
    query = "SELECT * FROM books WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    return cursor.fetchone() is None

def edit_book():
    edit_book_window = tk.Toplevel()
    edit_book_window.title("Edit Book")
    edit_book_window.geometry("{0}x{1}+0+0".format(edit_book_window.winfo_screenwidth(), edit_book_window.winfo_screenheight()))

    edit_book_window.configure(bg='#9162e2')
    BACKGROUND_IMAGE_PATH12 = 'bgcen.png'
    # Load the background image
    background_image = tk.PhotoImage(file=BACKGROUND_IMAGE_PATH12)

    # Create a Label to display the background image
    background_label = tk.Label(edit_book_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    # lef_f = tk.Frame(master=edit_book_window, bg='#a7f1b2', highlightbackground='gray15', highlightthickness=1, width=200)
    # lef_f.pack(side='left', fill="both", expand=False)

    


    cent_f = ctk.CTkFrame(master=edit_book_window,fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"), width=450, height=500)
    cent_f.pack(pady=(40, 0))

    entry_config = {'font': ('times new roman', 13), 'width': 20}

    tk.Label(cent_f, text="Enter Book ID to Edit:", font=("times new roman", 13, 'bold'), width=20, bg="#cbee76").place(x=23, y=20)
    entry_book_id = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter BookID",border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_book_id.place(x=230, y=20)

    label_config2 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 10}

    tk.Label(cent_f, text="Book Name:", **label_config2).place(x=80, y=148)
    tk.Label(cent_f, text="Author:", **label_config2).place(x=111, y=180)
    tk.Label(cent_f, text="Publish Year:", **label_config2).place(x=69, y=210)
    tk.Label(cent_f, text="Genre:", **label_config2).place(x=116, y=240)
    tk.Label(cent_f, text="Language:", **label_config2).place(x=92, y=270)
    tk.Label(cent_f, text="Publisher:", **label_config2).place(x=90, y=300)
    tk.Label(cent_f, text="Added Date:", **label_config2).place(x=80, y=330)
    tk.Label(cent_f, text="Total Copies:", **label_config2).place(x=70, y=360)
    tk.Label(cent_f, text="Shelf Location:", **label_config2).place(x=58, y=390)

    # Set a vertical gap (row spacing) between labels
    row_gap = 30
    for i in range(10):
        edit_book_window.grid_rowconfigure(i, minsize=row_gap)

    entry_book_name = ctk.CTkEntry(cent_f,border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_author = ctk.CTkEntry(cent_f, border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_publish_year = ctk.CTkEntry(cent_f,border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_genre = ctk.CTkEntry(cent_f, border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_language = ctk.CTkEntry(cent_f, border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_publisher = ctk.CTkEntry(cent_f, border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_total_copies = ctk.CTkEntry(cent_f, validate='key', border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_shelf_location = ctk.CTkEntry(cent_f, border_width=1,border_color="#15a613",width=200,font=('times new roman', 17),fg_color=("white"),text_color="black")

    entry_book_name.place(x=200, y=150)
    entry_author.place(x=200, y=180)
    entry_publish_year.place(x=200, y=210)
    entry_genre.place(x=200, y=240)
    entry_language.place(x=200, y=270)
    entry_publisher.place(x=200, y=300)

    # Replace the entry_added_date with DateEntry widget
    entry_added_date = DateEntry(cent_f,border_color="#15a613",border_width=2 ,**entry_config, date_pattern="YYYY-MM-DD")
    entry_added_date.place(x=200, y=332)
    entry_added_date.delete(0, 'end')

    entry_total_copies.place(x=200, y=360)
    entry_shelf_location.place(x=200, y=390)

    # # Validate entry_total_copies as it should only accept integers
    # validate_int = edit_book_window.register(lambda s: s.isdigit() or s == "")
    # entry_total_copies.configure(validate="key", validatecommand=(validate_int, "%P"))

    # Function to get book details and display them
    def display_book_details():
        book_id = entry_book_id.get()
        if not check_book_id_uniqueness(book_id):
            book_details = get_book_details(book_id)

            entry_book_name.delete(0, 'end')
            entry_author.delete(0, 'end')
            entry_publish_year.delete(0, 'end')
            entry_genre.delete(0, 'end')
            entry_language.delete(0, 'end')
            entry_publisher.delete(0, 'end')
            entry_added_date.delete(0, 'end')
            entry_total_copies.delete(0, 'end')
            entry_shelf_location.delete(0, 'end')

            entry_book_name.insert(0, book_details[1])
            entry_author.insert(0, book_details[2])
            entry_publish_year.insert(0, book_details[3])
            entry_genre.insert(0, book_details[4])
            entry_language.insert(0, book_details[5])
            entry_publisher.insert(0, book_details[6])
            entry_added_date.set_date(book_details[7])  # Set the DateEntry widget with the retrieved date
            entry_total_copies.insert(0, book_details[8])
            entry_shelf_location.insert(0, book_details[9])
        else:
            messagebox.showerror("Error", "Book ID not found", parent=edit_book_window)
            entry_book_name.delete(0, 'end')
            entry_author.delete(0, 'end')
            entry_publish_year.delete(0, 'end')
            entry_genre.delete(0, 'end')
            entry_language.delete(0, 'end')
            entry_publisher.delete(0, 'end')
            entry_added_date.delete(0, 'end')
            entry_total_copies.delete(0, 'end')
            entry_shelf_location.delete(0, 'end')

    # Button to display current book details
    btn = ctk.CTkButton(cent_f, text="Display Details", command=display_book_details, width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=170, y=70)

    # Function to save edited book details
    def save_edited_details():
        book_id = entry_book_id.get()
        book_name = entry_book_name.get()
        author = entry_author.get()
        publish_year = entry_publish_year.get()
        genre = entry_genre.get()
        language = entry_language.get()
        publisher = entry_publisher.get()
        added_date = entry_added_date.get()
        total_copies = entry_total_copies.get()
        shelf_location = entry_shelf_location.get()

        if not book_id or not book_name or not author or not publish_year or not genre or not language or not publisher or not added_date or not total_copies or not shelf_location:
            messagebox.showwarning("warning", "Don't leave any field empty!!", parent=edit_book_window)
            return

        update_book_details(book_id, book_name, author, publish_year, genre, language, publisher,
                            added_date, total_copies, shelf_location)
        messagebox.showinfo("Success", "Book details updated successfully!", parent=edit_book_window)
        entry_book_name.delete(0, 'end')
        entry_author.delete(0, 'end')
        entry_publish_year.delete(0, 'end')
        entry_genre.delete(0, 'end')
        entry_language.delete(0, 'end')
        entry_publisher.delete(0, 'end')
        entry_added_date.delete(0, 'end')
        entry_total_copies.delete(0, 'end')
        entry_shelf_location.delete(0, 'end')

    # Button to save edited book details
    btn = ctk.CTkButton(cent_f, text="Save",  command=save_edited_details,width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=158, y=450)

    # Button to go back to admin options window
    btn = ctk.CTkButton(cent_f, text="Back", command=edit_book_window.destroy, width=70,cursor='hand2',hover_color="pink",fg_color="gray",font=("times new roman", 18),text_color="black")
    
    btn.place(x=237, y=451)

# Function to update book details in the database
def update_book_details(book_id, book_name, author, publish_year, genre, language, publisher,
                        added_date, total_copies, shelf_location):
    query = """
    UPDATE books
    SET book_name = %s, author = %s, publish_year = %s, genre = %s, language = %s,
        publisher = %s, added_date = %s, total_copies = %s, shelf_location = %s
    WHERE book_id = %s
    """
    values = (book_name, author, publish_year, genre, language, publisher,
              added_date, total_copies, shelf_location, book_id)
    cursor.execute(query, values)
    db.commit()


def insert_issued_book(book_id, student_name, student_roll, student_class,issue_date):
    

    query = """
    INSERT INTO issued (book_id,student_name, roll_number, student_class, issued_date)
    VALUES (%s, %s, %s, %s, %s)
    """
    values = (book_id, student_name, student_roll, student_class, issue_date)
    
    cursor.execute(query, values)
    db.commit()




def issue_books():
    # Create a new window for issuing books
    issue_books_window = tk.Toplevel()
    issue_books_window.title("Issue Books")
    issue_books_window.geometry("{0}x{1}+0+0".format(issue_books_window.winfo_screenwidth(), issue_books_window.winfo_screenheight()))

    issue_books_window.configure(bg='#9162e2')
    BACKGROUND_IMAGE_PATH12 = 'bgcen.png'
    # Load the background image
    background_image = tk.PhotoImage(file=BACKGROUND_IMAGE_PATH12)

    # Create a Label to display the background image
    background_label = tk.Label(issue_books_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    # lef_f = tk.Frame(master=issue_books_window, bg='#a7f1b2', highlightbackground='gray15', highlightthickness=1, width=200)
    # lef_f.pack(side='left', fill="both", expand=False)

    


    cent_f = ctk.CTkFrame(master=issue_books_window, fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"), width=400, height=300)
    cent_f.pack(pady=(140, 0))

    label_config2 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 10}
    # Labels and Entry Fields for Issued Book Information
    tk.Label(cent_f, text="Book ID:", **label_config2).place(x=80, y=50)
    tk.Label(cent_f, text="Student Roll:", **label_config2).place(x=49, y=80)
    tk.Label(cent_f, text="Student Name:", **label_config2).place(x=39, y=110)
    tk.Label(cent_f, text="Class:", **label_config2).place(x=99, y=140)
    tk.Label(cent_f, text="Issue Date:", **label_config2).place(x=65, y=170)

    # Set a vertical gap (row spacing) between labels
    row_gap = 30
    for i in range(10):
        issue_books_window.grid_rowconfigure(i, minsize=row_gap)

    entry_config = {'font': ('times new roman', 13), 'width': 18}
    entry_book_id = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter BookID",border_color="#15a613",width=183,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_student_roll = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter Roll number",border_color="#15a613",width=183,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_student_name = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter student name",border_color="#15a613",width=183,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_class = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter class",border_color="#15a613",width=183,font=('times new roman', 17),fg_color=("white"),text_color="black")

    # Replace entry_issue_date with DateEntry widget
    entry_issue_date = DateEntry(cent_f, border_color="#15a613",border_width=2,**entry_config, date_pattern="YYYY-MM-DD")
    entry_issue_date.place(x=170, y=170)

    entry_book_id.place(x=170, y=50)
    entry_student_roll.place(x=170, y=80)
    entry_student_name.place(x=170, y=110)
    entry_class.place(x=170, y=140)

    # Function to issue the book
    def issue_book():
        book_id = entry_book_id.get()
        student_roll = entry_student_roll.get()
        student_name = entry_student_name.get()
        student_class = entry_class.get()
        issue_date = entry_issue_date.get()

        # Validate that all fields are filled
        if not book_id or not student_roll or not student_name or not student_class or not issue_date:
            messagebox.showwarning("Warning", "Please fill every field", parent=issue_books_window)
            return

        # Check if the book id exists in the database
        if not book_id_exists(book_id):
            messagebox.showwarning("Warning", "Book ID not found", parent=issue_books_window)
            return
        
        # Check if the book is already issued
        if is_book_issued(book_id):
            messagebox.showwarning("Warning", "Book is already issued", parent=issue_books_window)
            return

        # Insert the issued book details into the database
        insert_issued_book(book_id, student_name, student_roll,  student_class, issue_date)
        messagebox.showinfo("Success", "Book issued successfully!", parent=issue_books_window)

        # Clear the entry fields after issuing the book
        entry_book_id.delete(0,'end')
        entry_student_roll.delete(0,'end')
        entry_student_name.delete(0,'end')
        entry_class.delete(0,'end')
        #entry_issue_date.delete(0,'end')

    # Button to issue the book
    btn = ctk.CTkButton(cent_f, text="Issue Book",  command=issue_book, width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=110, y=225)

    # Button to go back to the main admin options window
    btn = ctk.CTkButton(cent_f, text="Back",  command=issue_books_window.destroy, width=70,cursor='hand2',hover_color="pink",fg_color="gray",font=("times new roman", 18),text_color="black")
    
    btn.place(x=220, y=225)

def book_id_exists(book_id):
    query = "SELECT COUNT(*) FROM books WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    result = cursor.fetchone()
    return result[0] > 0

def is_book_issued(book_id):
    query = "SELECT COUNT(*) FROM issued WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    result = cursor.fetchone()
    return result[0] > 0

def return_books():
    # Create a new window for returning books
    return_books_window = tk.Toplevel()
    return_books_window.title("Return Books")
    return_books_window.geometry("{0}x{1}+0+0".format(return_books_window.winfo_screenwidth(), return_books_window.winfo_screenheight()))

    return_books_window.configure(bg='#9162e2')
    BACKGROUND_IMAGE_PATH12 = 'bgcen.png'
    # Load the background image
    background_image = tk.PhotoImage(file=BACKGROUND_IMAGE_PATH12)

    # Create a Label to display the background image
    background_label = tk.Label(return_books_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    # lef_f = tk.Frame(master=return_books_window, bg='#a7f1b2', highlightbackground='gray15', highlightthickness=2, width=200)
    # lef_f.pack(side='left', fill="both", expand=False)

    

    cent_f = ctk.CTkFrame(master=return_books_window,fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"), width=350, height=200)
    cent_f.pack(pady=(180, 0))

    label_config22 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 10}
    label_config2 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 10, 'width': 14}
    # Labels and Entry Fields for Returning Book Information
    tk.Label(cent_f, text="Book ID:", **label_config22).place(x=67, y=40)
    tk.Label(cent_f, text="Returning Date:", **label_config2).place(x=5, y=70)

    entry_config = {'font': ('times new roman', 13), 'width': 17}
    entry_return_book_id = ctk.CTkEntry(cent_f, border_width=1,placeholder_text="Enter BookID",border_color="#15a613",width=177,font=('times new roman', 17),fg_color=("white"),text_color="black")
    
    # Replace entry_return_date with DateEntry widget
    entry_return_date = DateEntry(cent_f,border_color="#15a613",border_width=2, **entry_config, date_pattern="YYYY-MM-DD")

    entry_return_book_id.place(x=155, y=40)
    entry_return_date.place(x=155, y=70)

    # Function to return the book
    def return_book():
        book_id = entry_return_book_id.get()
        return_date = entry_return_date.get()

        # Validate that all fields are filled
        if not book_id or not return_date:
            messagebox.showwarning("Warning", "Please fill every field", parent=return_books_window)
            return

        # Check if the book id exists in the database
        if not book_id_exists(book_id):
            messagebox.showwarning("Warning", "Book ID not found", parent=return_books_window)
            return

        # Check if the book is issued
        if not is_book_issued(book_id):
            messagebox.showwarning("Warning", "Book is not issued", parent=return_books_window)
            return

        # Get the issued details for the book
        issued_details = get_issued_details(book_id)

        # Calculate the fine if returning after 7 days
        issue_date = issued_details['issued_date']

        return_date = datetime.strptime(return_date, "%Y-%m-%d").date()

        days_difference = (return_date - issue_date).days

        fine = max(0, days_difference - 7) * 5  # Fine of 5 rupees per day after 7 days

        # Display the book and student details along with fine
        return_details = f"Book ID: {issued_details['book_id']}\nStudent Name: {issued_details['student_name']}\nRoll Number: {issued_details['roll_number']}\nClass: {issued_details['student_class']}\n"
        return_details += f"Issued Date: {issued_details['issued_date']}\nReturning Date: {return_date.strftime('%Y-%m-%d')}\nFine: {fine} Rupees"

        messagebox.showinfo("Book Returned Successfully", return_details, parent=return_books_window)

        # Remove the book details from the issued table
        remove_issued_book(book_id)

        # Clear the entry fields after returning the book
        entry_return_book_id.delete(0,'end')
        #entry_return_date.delete(0,'end')

    # Button to return the book
    btn = ctk.CTkButton(cent_f, text="Return Book",  command=return_book, width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=75, y=130)

    # Button to go back to the main admin options window
    btn = ctk.CTkButton(cent_f, text="Back", command=return_books_window.destroy, width=70,cursor='hand2',hover_color="pink",fg_color="gray",font=("times new roman", 18),text_color="black")
    
    btn.place(x=205, y=130)


def get_issued_details(book_id):
    query = "SELECT * FROM issued WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    result = cursor.fetchone()

    column_names = [desc[0] for desc in cursor.description]
    issued_details = dict(zip(column_names, result))

    return issued_details

def remove_issued_book(book_id):
    query = "DELETE FROM issued WHERE book_id = %s"
    cursor.execute(query, (book_id,))
    db.commit()
        

def fetch_issued_books():
    # Execute a query to fetch all records from the "issued" table
    query = "SELECT book_id,student_name,roll_number,student_class,issued_date FROM issued"
    cursor.execute(query)
    issued_books = cursor.fetchall()
    return issued_books

def open_issued_books_window():
    # Create a new window for displaying issued books
    issued_books_window = tk.Toplevel(app)
    issued_books_window.title("Issued Books")
    issued_books_window.geometry("{0}x{1}+0+0".format(issued_books_window.winfo_screenwidth(), issued_books_window.winfo_screenheight()))

    style = ttk.Style(issued_books_window)
    style.theme_use("clam")
    style.configure("Treeview", background="#a7f1b2", font=('times new roman', 12))
    style.configure("Treeview.Heading", font=('times new roman', 12, 'bold'))
    
    # Create a Treeview widget for displaying the table
    tree = ttk.Treeview(issued_books_window)
    tree["columns"] = ("Book ID", "Student Name", "Roll Number", "Student Class", "Issued Date", "Due Date")

    # Define column names and column order
    column_names = ["Book ID", "Student Name", "Roll Number", "Student Class", "Issued Date", "Due Date"]
    tree["show"] = "headings"  # This will hide the default blank column

    # Configure columns
    for col_name in column_names:
        tree.heading(col_name, text=col_name, anchor=tk.CENTER)  # Align header text to center
        tree.column(col_name, width=100, anchor=tk.CENTER)  # Align cell data to center

    # Fetch issued books from the database
    issued_books = fetch_issued_books()

    # Insert data into the treeview
    for book in issued_books:
        book_id, student_name, roll_number, student_class, issued_date = book
        issued_date_str = issued_date.strftime("%Y-%m-%d")  # Convert issued_date to string
        due_date = issued_date + timedelta(days=7)  # Calculate due date as 7 days after issued date
        due_date_str = due_date.strftime("%Y-%m-%d")
        tree.insert("", tk.END, values=(book_id, student_name, roll_number, student_class, issued_date_str, due_date_str))

    # Pack the treeview
    tree.pack(expand=True, fill=tk.BOTH)



# Create and place GUI widgets for the main window
app = tk.Tk()
app.title("Library Management System")
app.configure(bg='gray1')

app.geometry("{0}x{1}+0+0".format(app.winfo_screenwidth(), app.winfo_screenheight()))

top_f=ctk.CTkFrame(master=app,fg_color="#cbe6b9",border_width=2,border_color="#15a613",corner_radius=60,background_corner_colors=("#cbee76","#cbee76","#cbee76","#cbee76"))
top_f.pack(side='top',fill="both",expand=False)

l2=tk.Label(top_f, text="LIBRARY MANAGEMENT SYSTEM",fg='black', font=("Algerian", 50),bg='#cbe6b9')
l2.pack(pady=(50,50),padx=(90,0))

log_f=ctk.CTkFrame(master=top_f,height=80,width=80,fg_color="#cbee76",border_width=2,border_color="#15a613",corner_radius=40,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"))
#log_f.pack(pady=(50,50),padx=(30,1100))
log_f.place(x=80,y=50)
BACKGROUND_IMAGE_PATH = 'logo1.png'
# Load the background image
background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH)

# Create a Label to display the background image
background_label = tk.Label(log_f, image=background_image,width=60,height=60)
background_label.place(relwidth=1, relheight=1)
# Set the background image to be transparent
background_label.image = background_image


bot_f=tk.Frame(master=app,bg='gray',highlightbackground='green',height=500,width=1300,highlightthickness=1)
bot_f.pack(pady=(0,0))


BACKGROUND_IMAGE_PATH = 'firbg111.png'
# Load the background image
background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH)

# Create a Label to display the background image
background_label = tk.Label(bot_f, image=background_image,width=1300,height=500)
background_label.place(relwidth=1, relheight=1)
# Set the background image to be transparent
background_label.image = background_image




# cent_f=tk.Frame(master=bot_f,bg='gray18',highlightbackground='gray15',highlightthickness=2,width=600,height=300)
# #cent_f.grid(row=400,column=400)
# cent_f.pack(pady=(50,0))

# BACKGROUND_IMAGE_PATH = 'nBook4.png'
# # Load the background image
# background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH)

# # Create a Label to display the background image
# background_label = tk.Label(cent_f, image=background_image,width=60,height=60)
# background_label.place(relwidth=1, relheight=1)





def open_admin_window():
    create_admin_table()

    # Check if there are existing admin credentials
    cursor.execute("SELECT COUNT(*) FROM admin")
    num_rows = cursor.fetchone()[0]

    if num_rows > 0:
        # If admin credentials are already set, prompt to enter credentials
        open_admin_login_window()
    else:
        # If admin credentials are not set, prompt to set new credentials
        set_new_admin_credentials()

# Function to set new admin credentials
def set_new_admin_credentials():
    new_credentials_window = tk.Toplevel(app)
    new_credentials_window.title("Set Admin Credentials")
    new_credentials_window.geometry("{0}x{1}+0+0".format(new_credentials_window.winfo_screenwidth(), new_credentials_window.winfo_screenheight()))
    

    BACKGROUND_IMAGE_PATH22='admbg1.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH22)

    # Create a Label to display the background image
    background_label = tk.Label(new_credentials_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    new_credentials_window.configure(bg='gray1')
    cent_f=ctk.CTkFrame(master=new_credentials_window,fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"),width=350,height=300)
    #cent_f.grid(row=400,column=400)
    cent_f.pack(pady=(100,0))
    
    ctk.CTkLabel(master=cent_f,text="SET CREDENTIALS",width=120,fg_color="#cbee76",text_color="black",font=('Imprint MT Shadow', 30)).place(x=25,y=40)
    entry_config = {'font': ('times new roman', 13,'bold'), 'width': 13}
    tk.Label(cent_f, text="New Username:",**entry_config,bg='#cbee76').place(x=32,y=110)
    tk.Label(cent_f, text="New Password:",**entry_config,bg='#cbee76').place(x=32,y=150)

    entry_configg = {'font': ('times new roman', 13), 'width': 15}
    entry_new_username = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter username",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_new_password = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter password",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black" ,show="*")

    entry_new_username.place(x=168,y=110)
    entry_new_password.place(x=168,y=150)

    def my_show():
        if entry_new_password.cget('show')=='*':
            entry_new_password.configure(show='')
        else:
            entry_new_password.configure(show='*')
    
    cb=ctk.CTkCheckBox(cent_f,text='Show password',command=my_show,text_color="black",font=("times new roman", 13))
    cb.place(x=200,y=185)

    def save_credentials():
        new_username = entry_new_username.get()
        new_password = entry_new_password.get()

        # Check if new username and password are not empty
        if not new_username or not new_password:
            messagebox.showwarning("Warning", "Username and password cannot be blank",parent=new_credentials_window)
            return

        # Insert the new credentials into the database
        insert_initial_admin(new_username, new_password)
        messagebox.showinfo("Success", "Admin credentials set successfully!")
        new_credentials_window.destroy()
        open_admin_login_window()

    btn=ctk.CTkButton(cent_f, text="Save",command=save_credentials,width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=140,y=230)


# Create a new function for handling admin credentials edit
def edit_admin_credentials():
    # Retrieve the current credentials
    query = "SELECT * FROM admin"
    cursor.execute(query)
    current_credentials = cursor.fetchone()

    # Create a window for editing credentials
    edit_credentials_window = tk.Toplevel(app)
    edit_credentials_window.title("Edit Admin Credentials")
    edit_credentials_window.geometry("{0}x{1}+0+0".format(edit_credentials_window.winfo_screenwidth(), edit_credentials_window.winfo_screenheight()))

    BACKGROUND_IMAGE_PATH22='admbg1.png'
    # Load the background image
    background_image = PhotoImage(file=BACKGROUND_IMAGE_PATH22)

    # Create a Label to display the background image
    background_label = tk.Label(edit_credentials_window, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    # Set the background image to be transparent
    background_label.image = background_image
    edit_credentials_window.configure(bg='gray1')
    cent_f=ctk.CTkFrame(master=edit_credentials_window,fg_color="#cbee76",border_width=5,border_color="#15a613",corner_radius=30,background_corner_colors=("#15a613","#15a613","#15a613","#15a613"),width=400,height=400)
    #cent_f.grid(row=400,column=400)
    cent_f.pack(pady=(100,0))

    ctk.CTkLabel(master=cent_f,text="EDIT CREDENTIALS",width=120,fg_color="#cbee76",text_color="black",font=('Imprint MT Shadow', 30)).place(x=45,y=40)

    label_config2 = {'font': ('times new roman', 13, 'bold'), 'bg': '#cbee76', 'padx': 10, 'width': 18}
    tk.Label(cent_f, text="Current Username:",**label_config2).place(x=20,y=110)
    tk.Label(cent_f, text="Current Password:",**label_config2).place(x=21,y=140)

    # Set a vertical gap (row spacing) between labels
    row_gap = 30
    for i in range(10):
        edit_credentials_window.grid_rowconfigure(i, minsize=row_gap)
    entry_config = {'font': ('times new roman', 13), 'width': 15}
    entry_current_username = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter username",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black")
    entry_current_password = ctk.CTkEntry(cent_f,border_width=1,show="*",placeholder_text="Enter username",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black")

    entry_current_username.place(x=205,y=110)
    entry_current_password.place(x=205,y=140)

    

    def check_current_credentials():
        current_username = entry_current_username.get()
        current_password = entry_current_password.get()

        # Check if the entered credentials are correct
        if current_username == current_credentials[0] and current_password == current_credentials[1]:
            # Credentials are correct, allow editing

            
            tk.Label(cent_f, text="New Username:",**label_config2).place(x=27,y=250)
            tk.Label(cent_f, text="New Password:",**label_config2).place(x=27,y=280)

            entry_config = {'font': ('times new roman', 13), 'width': 15}
            entry_new_username = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter username",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black")
            entry_new_password = ctk.CTkEntry(cent_f,border_width=1,placeholder_text="Enter username",border_color="#15a613",width=150,font=('times new roman', 17),fg_color=("white"),text_color="black",show="*")

            entry_new_username.place(x=200,y=250)
            entry_new_password.place(x=200,y=280)

            def my_show():
                if entry_new_password.cget('show')=='*':
                    entry_new_password.configure(show='')
                else:
                    entry_new_password.configure(show='*')
    
            cb=ctk.CTkCheckBox(cent_f,text='Show password',command=my_show,text_color="black",font=("times new roman", 13))
            cb.place(x=230,y=315)

            def save_edited_credentials():
                new_username = entry_new_username.get()
                new_password = entry_new_password.get()

                # Check if new username and password are not empty
                if not new_username or not new_password:
                    messagebox.showwarning("Warning", "Username and password cannot be blank",parent=edit_credentials_window)
                    return

                # Update the admin credentials in the database
                query = "UPDATE admin SET username = %s, password = %s"
                values = (new_username, new_password)
                cursor.execute(query, values)
                db.commit()

                messagebox.showinfo("Success", "Admin credentials updated successfully!")
                edit_credentials_window.destroy()

            btn=ctk.CTkButton(cent_f, command=save_edited_credentials,text="Save",width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
            
            btn.place(x=169,y=350)
        else:
            # Credentials are incorrect, show a warning
            messagebox.showwarning("Warning", "Incorrect current username or password. Cannot edit credentials.",parent=edit_credentials_window)

    btn=ctk.CTkButton(cent_f, command=check_current_credentials, text="Next",width=70,cursor='hand2',hover_color="pink",fg_color="sky blue",font=("times new roman", 18),text_color="black")
    
    btn.place(x=170,y=200)


# Set a fixed width for the buttons
button_wid = 13


def on_hover(event):
    event.widget.configure(bg='pink')
def on_default(event):
    event.widget.configure(bg='#916e89')
def on_defaultE(event):
    event.widget.configure(bg='gray')

# Button to open the admin login window
btn=ctk.CTkButton(bot_f, text="ADMIN", command=open_admin_window,width=100,border_color="green",border_width=1,cursor='hand2',height=50,hover_color="pink",fg_color="#cbee76",font=("times new roman", 16),text_color="black")

btn.place(x=420,y=110)

# Button to open the admin login window
btn=ctk.CTkButton(bot_f, text="STUDENT", command=open_stud_options_window,border_color="green",border_width=1,width=100,height=50,cursor='hand2',hover_color="pink",fg_color="#cbee76",font=("times new roman", 16),text_color="black")

btn.place(x=560,y=110)

# Button to close the application
btn=ctk.CTkButton(bot_f, text="CLOSE", command=app.destroy,width=100,border_color="green",border_width=1,height=50,cursor='hand2',hover_color="pink",fg_color="#cbee76",font=("times new roman", 16),text_color="black")

btn.place(x=700,y=110)

# Run the Tkinter event loop
app.mainloop()



